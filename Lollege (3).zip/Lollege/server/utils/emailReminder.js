const express = require("express");
const router = express.Router();
const Task = require("../models/task");
const Student = require("../models/student");
const nodemailer = require("nodemailer");

const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASSWORD,
  },
});

router.post("/add", async (req, res) => {
  try {
    const { userRegno, title, description, startDateTime, deadline } = req.body;

    const task = new Task({
      userRegno,
      title,
      description,
      startDateTime,
      deadline,
      startReminderSent: false,
      deadlineReminderSent: false,
    });

    await task.save();

    const student = await Student.findOne({ registerNo: userRegno });
    console.log(
      "Email config:",
      process.env.EMAIL_USER,
      process.env.EMAIL_PASSWORD ? "✓" : "❌"
    );
    console.log("Sending to:", student.email);

    if (student && student.email) {
      await transporter.sendMail({
        from: process.env.EMAIL_USER,
        to: student.email,
        subject: `✅ Task Created: ${title}`,
        text: `Hi ${
          student.firstName || "Student"
        },\n\nYour task "${title}" has been successfully created.\n\nStart Time: ${new Date(
          startDateTime
        ).toLocaleString()}\nDeadline: ${new Date(
          deadline
        ).toLocaleString()}\n\nGood luck!\n\n— Lollege App`,
      });
    }

    res
      .status(200)
      .json({ message: "Task created and email sent (if available)." });
  } catch (error) {
    console.error("Error creating task or sending email:", error.message);
    res.status(500).json({ error: "Internal server error" });
  }
});

module.exports = router;
