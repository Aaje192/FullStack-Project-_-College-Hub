const mongoose = require("mongoose");

// Lollege DB connection
const lollegeConnection = mongoose.createConnection(
  process.env.LOLLEGE_DB_URI,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);

// Student DB connection
const studentConnection = mongoose.createConnection(
  process.env.STUDENT_DB_URI,
  {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  }
);

// Handling connection events for lollege DB
lollegeConnection.once("open", () => {
  console.log("Connected to lollege database!");
});

lollegeConnection.on("error", (err) => {
  console.error("Error connecting to lollege database:", err);
});

// Handling connection events for student DB
studentConnection.once("open", () => {
  console.log("Connected to student database!");
});

studentConnection.on("error", (err) => {
  console.error("Error connecting to student database:", err);
});

module.exports = { lollegeConnection, studentConnection };
