const router = require("express").Router();
const { User, validate } = require("../models/user");
const Student = require("../models/student");
const bcrypt = require("bcryptjs");

router.post("/", async (req, res) => {
  try {
    const { error } = validate(req.body);
    if (error)
      return res.status(400).send({ message: error.details[0].message });

    const user = await User.findOne({ email: req.body.email });
    if (user) return res.status(409).send({ message: "Email already exists" });

    const existingRegNo = await User.findOne({
      registerNo: req.body.registerNo,
    });
    if (existingRegNo)
      return res.status(409).send({ message: "Reg No already exists" });

    const salt = await bcrypt.genSalt(Number(process.env.SALT));
    const hashedPassword = await bcrypt.hash(req.body.password, salt);

    const newUser = await new User({
      ...req.body,
      password: hashedPassword,
    }).save();

    await new Student({
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      email: req.body.email,
      password: hashedPassword,
      registerNo: req.body.registerNo,
      dept: req.body.dept,
      role: req.body.role,
    }).save();

    res.status(201).send({ message: "User and Student created successfully" });
  } catch (err) {
    console.error("Registration error:", err);
    res.status(500).send({ message: "Internal Server Error" });
  }
});

module.exports = router; // ✅ This line is important
