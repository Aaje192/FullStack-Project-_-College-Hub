const express = require("express");
const { User } = require("../models/user");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Joi = require("joi");

const router = express.Router();

// Login Route
router.post("/", async (req, res) => {
  try {
    // Validate request data
    const { error } = validateLogin(req.body);
    if (error)
      return res.status(400).send({ message: error.details[0].message });

    // Find user by email
    const user = await User.findOne({ email: req.body.email });
    if (!user)
      return res.status(401).send({ message: "Invalid Email or Password" });

    // Compare password
    const validPassword = await bcrypt.compare(
      req.body.password,
      user.password
    );
    if (!validPassword)
      return res.status(401).send({ message: "Invalid Email or Password" });

    // Update login time
    user.loginTime = new Date();
    await user.save();

    // Generate JWT token
    const token = user.generateAuthToken();

    // Send response with token
    res.status(200).send({ data: token, message: "Logged in successfully" });
  } catch (error) {
    console.error(error); // Log detailed error for debugging
    res.status(500).send({ message: "Internal Server Error" });
  }
});

// Logout Route
router.post("/logout/:id", async (req, res) => {
  try {
    await User.findByIdAndUpdate(req.params.id, { logoutTime: new Date() });
    res.status(200).send({ message: "Logout time recorded" });
  } catch (err) {
    res.status(500).send({ message: "Error during logout" });
  }
});

// Login validation
const validateLogin = (data) => {
  const schema = Joi.object({
    email: Joi.string().email().required(),
    password: Joi.string().required(),
  });
  return schema.validate(data);
};

module.exports = router;
