const express = require("express");
const jwt = require("jsonwebtoken");
const router = express.Router();
const Student = require("../models/student"); // ✅ Use the model

// Middleware to verify JWT
const authMiddleware = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).send("No token provided");

  const token = authHeader.split(" ")[1];
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    return res.status(403).send("Invalid token");
  }
};

// GET /api/students/me
router.get("/me", authMiddleware, async (req, res) => {
  try {
    const student = await Student.findOne({
      email: req.user.email,
    }).select("-password");

    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (err) {
    console.error("Error fetching student:", err);
    res.status(500).json({ message: "Error fetching student data" });
  }
});

module.exports = router;
