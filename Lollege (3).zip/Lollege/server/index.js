require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");

const { lollegeConnection, studentConnection } = require("./db");
const userRoutes = require("./routes/users");
const authRoutes = require("./routes/auth");
const studentRoutes = require("./routes/student");
const taskRoutes = require("./routes/tasks");
const emailRoutes = require("./utils/emailReminder");
require("./utils/emailReminder"); // ✅ Just import, don't call anything

// Middlewares
app.use(express.json());
app.use(cors());

// Routes
app.use("/api/users", userRoutes);
app.use("/api/auth", authRoutes);
app.use("/api/students", studentRoutes);
app.use("/api/tasks", taskRoutes); // ✅ Task manager route
app.use("/api/tasks", emailRoutes);

const port = process.env.PORT || 8080;
app.listen(port, () => console.log(`✅ Server running on port ${port}...`));
