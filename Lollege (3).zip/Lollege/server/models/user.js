const mongoose = require("mongoose");
const { lollegeConnection } = require("../db");
const jwt = require("jsonwebtoken");
const Joi = require("joi");
const passwordComplexity = require("joi-password-complexity");

const userSchema = new mongoose.Schema({
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, enum: ["student", "staff"], required: true },
  dept: { type: String, required: true },
  registerNo: { type: String, required: true, unique: true },
  createdAt: { type: Date, default: Date.now },
  loginTime: { type: Date },
  logoutTime: { type: Date },
});

userSchema.methods.generateAuthToken = function () {
  const token = jwt.sign(
    {
      _id: this._id,
      email: this.email,
      role: this.role,
      registerNo: this.registerNo,
    },
    process.env.JWT_SECRET,
    { expiresIn: "7d" }
  );
  return token;
};

const User = lollegeConnection.model("User", userSchema);

const validate = (data) => {
  const schema = Joi.object({
    firstName: Joi.string().required(),
    lastName: Joi.string().required(),
    email: Joi.string().email().required(),
    password: passwordComplexity().required(),
    role: Joi.string().valid("student", "staff").required(),
    dept: Joi.string().required(),
    registerNo: Joi.string().required(),
  });
  return schema.validate(data);
};

module.exports = { User, validate };
