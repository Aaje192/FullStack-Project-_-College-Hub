const mongoose = require("mongoose");
const { studentConnection } = require("../db");

const studentSchema = new mongoose.Schema(
  {
    firstName: { type: String, required: true },
    lastName: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    registerNo: { type: String, required: true },
    dept: { type: String, required: true },
    role: { type: String, enum: ["student", "staff"], required: true },
    loginTime: { type: Date },
    logoutTime: { type: Date },
  },
  { timestamps: true }
);

module.exports = studentConnection.model("Student", studentSchema);
