import { Routes, Route, Navigate } from "react-router-dom";
import Main from "./components/Main";
import Signup from "./components/Signup";
import Login from "./components/Login";
import Dashboard from "./components/Dashboard";
import TaskManager from "./components/TaskManager";

function App() {
  const user = localStorage.getItem("token");
  console.log("hello");
  return (
    <Routes>
      <Route path="/" element={user ? <Main /> : <Navigate to="/login" />} />
      <Route path="/signup" element={<Signup />} />
      <Route path="/login" element={<Login />} />
      <Route
        path="/dashboard"
        element={user ? <Dashboard /> : <Navigate to="/login" />}
      />
      <Route path="/taskmanager" element={<TaskManager />} />
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default App;
