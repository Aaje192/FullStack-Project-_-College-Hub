import React, { useState, useEffect } from "react";
import styles from "./styles.module.css";
import axios from "axios";

const TaskManager = () => {
  const storedRegno = localStorage.getItem("regno");
  const [regno, setRegno] = useState(storedRegno || "");
  const [tasks, setTasks] = useState([]);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    startDateTime: "",
    deadline: "",
  });
  const [editingId, setEditingId] = useState(null);

  useEffect(() => {
    if (regno) {
      fetchTasks();
    }
  }, [regno]);

  const fetchTasks = async () => {
    try {
      const res = await axios.get(`http://localhost:8080/api/tasks/${regno}`);
      setTasks(res.data);
    } catch (err) {
      console.error(err);
      setTasks([]); // clear tasks on error
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!regno.trim()) {
      alert("Please enter your registration number.");
      return;
    }

    try {
      if (editingId) {
        await axios.put(
          `http://localhost:8080/api/tasks/update/${editingId}`,
          formData
        );
      } else {
        await axios.post("http://localhost:8080/api/tasks/add", {
          ...formData,
          userRegno: regno,
        });
      }
      fetchTasks();
      setFormData({
        title: "",
        description: "",
        startDateTime: "",
        deadline: "",
      });
      setEditingId(null);
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div className={styles.container}>
      <h2>{editingId ? "Edit Task" : "My Task Manager"}</h2>

      {/* Registration Number Input */}
      <input
        type="text"
        placeholder="Enter your Registration Number"
        value={regno}
        onChange={(e) => setRegno(e.target.value)}
        className={styles.input}
      />

      <form onSubmit={handleSubmit} className={styles.form}>
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={formData.title}
          onChange={handleChange}
          required
          className={styles.input}
        />
        <input
          type="text"
          name="description"
          placeholder="Description"
          value={formData.description}
          onChange={handleChange}
          required
          className={styles.input}
        />
        <label>Start Date and Time:</label>
        <input
          type="datetime-local"
          name="startDateTime"
          value={formData.startDateTime}
          onChange={handleChange}
          required
          className={styles.input}
        />
        <label>Deadline:</label>
        <input
          type="datetime-local"
          name="deadline"
          value={formData.deadline}
          onChange={handleChange}
          required
          className={styles.input}
        />
        <button type="submit" className={styles.green_btn}>
          {editingId ? "Update Task" : "Add Task"}
        </button>
      </form>

      <div className={styles.task_list}>
        {tasks.length === 0 ? (
          <p>No tasks available.</p>
        ) : (
          <ul>
            {tasks.map((task) => (
              <li key={task._id} className={styles.task_item}>
                <strong>{task.title}</strong> - {task.description}
                <br />
                Start: {new Date(task.startDateTime).toLocaleString()} <br />
                Deadline: {new Date(task.deadline).toLocaleString()}
                <br />
                <button
                  onClick={() => {
                    setFormData({
                      title: task.title,
                      description: task.description,
                      startDateTime: task.startDateTime,
                      deadline: task.deadline,
                    });
                    setEditingId(task._id);
                  }}
                  className={styles.white_btn}
                >
                  Edit
                </button>
                <button
                  onClick={() => {
                    axios
                      .delete(
                        `http://localhost:8080/api/tasks/delete/${task._id}`
                      )
                      .then(fetchTasks)
                      .catch(console.error);
                  }}
                  className={styles.green_btn}
                >
                  Delete
                </button>
                <hr />
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default TaskManager;
