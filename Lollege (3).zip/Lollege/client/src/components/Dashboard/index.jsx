import { useEffect, useState } from "react";
import axios from "axios";
import { Navigate, useNavigate } from "react-router-dom";
import styles from "./styles.module.css";

const Dashboard = () => {
  const [student, setStudent] = useState(null);
  const [loading, setLoading] = useState(true);
  const token = localStorage.getItem("token");
  const navigate = useNavigate();

  const goToTaskManager = () => {
    navigate("/taskmanager"); // route path to Task Manager page
  };

  useEffect(() => {
    const fetchStudent = async () => {
      try {
        const res = await axios.get("http://localhost:8080/api/students/me", {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });
        setStudent(res.data);
      } catch (err) {
        console.error("Error fetching student:", err);
      } finally {
        setLoading(false);
      }
    };

    if (token) fetchStudent();
  }, [token]);

  if (!token) return <Navigate to="/login" />;
  if (loading) return <div className={styles.login_container}>Loading...</div>;

  return (
    <div className={styles.login_container}>
      <div className={styles.login_form_container}>
        <div className={styles.left}>
          <div className={styles.form_container}>
            <h1>Student Dashboard</h1>
            <div className={styles.input}>
              <strong>Name:</strong> {student.firstName} {student.lastName}
            </div>
            <div className={styles.input}>
              <strong>Email:</strong> {student.email}
            </div>
            <div className={styles.input}>
              <strong>Register No:</strong> {student.registerNo}
            </div>
            <div className={styles.input}>
              <strong>Department:</strong> {student.dept}
            </div>
            <div className={styles.input}>
              <strong>Role:</strong> {student.role}
            </div>
            <div className={styles.input}>
              <strong>Last Login:</strong> {student.loginTime || "N/A"}
            </div>
            <div className={styles.input}>
              <strong>Last Logout:</strong> {student.logoutTime || "N/A"}
            </div>
            <div>
              <button onClick={goToTaskManager}>Go to Task Manager</button>
            </div>
          </div>
        </div>
        <div className={styles.right}>
          <h1>Welcome</h1>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
